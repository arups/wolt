Development of Restarant API using Node JS


1. Install node.js
2. Unzip the source code and put it in any folder.
3. just type in the console node app.js

The app should be up and running

Access the service with http://127.0.0.1:8081/restaurants/search?q=Momotoko&lat=60.17045&lon=24.93147
